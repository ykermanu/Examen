public class Heroes {
    String nombre;
    String raza;
    int nivelPoder;
    String Habilidad;

    public Heroes() {
        this.nombre = "Desconocido";
        this.raza = "Humano";
        this.nivelPoder = 3;
        Habilidad = "Ninguno";
    }

    public Heroes(String nombre, String raza, int nivelPoder, String habilidad) {
        this.nombre = nombre;
        this.raza = raza;
        this.nivelPoder = nivelPoder;
        Habilidad = habilidad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRaza() {

        return raza;
    }

    public void setRaza(String raza) {

        this.raza = raza;
    }

    public int getNivelPoder() {

        return nivelPoder;
    }

    public void setNivelPoder(int nivelPoder) {
        this.nivelPoder = nivelPoder;
    }

    public String getHabilidad() {
        return Habilidad;

    }
    public void setHabilidad(String habilidad) {
        Habilidad = habilidad;
    }
}

