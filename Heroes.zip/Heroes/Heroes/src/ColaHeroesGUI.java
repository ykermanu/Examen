import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class ColaHeroesGUI {
    private JPanel pGeneral;
    private JTextArea textArea; // Para mostrar los héroes
    private JTextArea textArea1; // Para mostrar la nueva cola, si es necesario
    private JTextField texthabilidad;
    private JTextField textnombre;
    private JTextField textpoder;
    private JTextField textraza;
    private JButton Anadir;
    private JButton mostrar;
    private ColaHeroes colaHeroes;

    public ColaHeroesGUI() {
        colaHeroes = new ColaHeroes();

        // Listeners para los JTextFields (puedes agregar validaciones aquí si lo deseas)
        textnombre.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                super.keyTyped(e);
            }
        });
        textraza.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                super.keyTyped(e);
            }
        });
        textpoder.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                super.keyTyped(e);
            }
        });
        texthabilidad.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                super.keyTyped(e);
            }
        });

        // Acción del botón "Añadir"
        Anadir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = textnombre.getText();
                String raza = textraza.getText();
                int poder;

                try {
                    poder = Integer.parseInt(textpoder.getText());
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Por favor, ingresa un número válido para el poder.");
                    return;
                }

                String habilidad = texthabilidad.getText();

                Heroes nuevoHeroe = new Heroes(nombre, raza, poder, habilidad);
                colaHeroes.encolarHeroes(nuevoHeroe); // Ahora solo se pasa el héroe sin argumentos adicionales

                // Limpiar los campos de texto después de añadir
                textnombre.setText("");
                textraza.setText("");
                textpoder.setText("");
                texthabilidad.setText("");
            }
        });


        // Acción del botón "Mostrar"
        // Acción del botón "Mostrar"
        mostrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textArea.setText(""); // Limpiar el área de texto antes de mostrar

                // Crear un arreglo de héroes
                Heroes heroep[] = {
                        new Heroes("Thanos", "alienígena", 1000000000, "Superfuerza"),
                        new Heroes("Wolverine", "mutante", 100000, "Superregeneración"),
                        new Heroes("Quicksilver", "mutante", 1000, "Supervelocidad"),
                        new Heroes("Hulk", "humano", 100000000, "Superfuerza")
                };

                // Mostrar héroes del arreglo
                for (Heroes heroe : heroep) {
                    double poderTotal = colaHeroes.calcularPoder(heroe);
                    textArea.append(String.format("Nombre: %s, Habilidad: %s, Poder Total: %.2f\n",
                            heroe.getNombre(), heroe.getHabilidad(), poderTotal));
                }

                // Mostrar héroes de la cola
                if (colaHeroes.getCola() != null && !colaHeroes.getCola().isEmpty()) {
                    for (Heroes heroe : colaHeroes.getCola()) {
                        double poderTotal = colaHeroes.calcularPoder(heroe);
                        textArea.append(String.format("Nombre: %s, Habilidad: %s, Poder Total: %.2f\n",
                                heroe.getNombre(), heroe.getHabilidad(), poderTotal));
                    }
                } else {
                    textArea.append("No hay héroes en la cola.\n");
                }
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("ColaHeroesGUI");
        frame.setContentPane(new ColaHeroesGUI().pGeneral);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}



