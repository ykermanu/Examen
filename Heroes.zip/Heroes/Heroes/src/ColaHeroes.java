import javax.swing.*;
import java.util.LinkedList;

public class ColaHeroes {
    private LinkedList<Heroes> cola;

    // Constructor inicializa la cola de héroes.
    public ColaHeroes() {
        cola = new LinkedList<>();
    }
    public LinkedList<Heroes> getCola() {

        return cola; // Devuelve la lista de héroes
    }


    // Método para agregar héroes a la cola. (eliminar argumentos)
    public void encolarHeroes(Heroes heroe) {
        Heroes hero[] = {
                new Heroes("Thanos", "alienígena", 1000000000, "Superfuerza"),
                new Heroes("Wolverine", "mutante", 100000, "Superregeneración"),
                new Heroes("Quicksilver", "mutante", 1000, "Supervelocidad"),
                new Heroes("Hulk", "humano", 100000000, "Superfuerza")
        };
        cola.add(heroe);
    }

    // Método para calcular el poder de un héroe según su raza.
    public double calcularPoder(Heroes heroe) {
        double nivelPoder = heroe.getNivelPoder();

        switch (heroe.getRaza().toLowerCase()) {
            case "mutante":
                nivelPoder *= 1.3;
                break;
            case "alienígena":
                nivelPoder *= 1.5;
                break;
            default:
                // No hay cambio porque es humano
                break;
        }

        return nivelPoder;
    }

}
